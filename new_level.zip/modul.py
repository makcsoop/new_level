import pygame
import os
import sys

pygame.init()

all_sprites = pygame.sprite.Group()
hero_group = pygame.sprite.Group()
barriers = pygame.sprite.Group()
HERBAL_COLOR = (93, 161, 48)
TEXT_COLOR = (76, 80, 82)
WINDOW_SIZE = (600, 600)
SELL_SIZE = (60, 60)
STEP_MAR = 60
show_fon = True
clock = pygame.time.Clock()
intro_text = ["ЗАСТАВКА", "",
              "Правила игры",
              "Если в правилах несколько строк,",
              "приходится выводить их построчно"]
font = pygame.font.Font(None, 30)


def load_image(name: str, colorkey=None) -> pygame.surface.Surface:
    """Загрузка изображения из папки data"""
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def do_up(character, is_shell=False) -> None:
    character.rect.y -= STEP_MAR


def do_right(character, is_shell=False) -> None:
    character.rect.x += STEP_MAR


def do_down(character, is_shell=False) -> None:
    character.rect.y += STEP_MAR


def do_left(character, is_shell=False) -> None:
    character.rect.x -= STEP_MAR


class Hero(pygame.sprite.Sprite):
    def __init__(self, *group, x, y):
        super(Hero, self).__init__(*group)

        self.image = load_image('mar.png', (255, 255, 255))
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x, self.rect.y = x, y
        self.do_up, self.do_right, self.do_down, self.do_left = False, False, False, False

    def update(self):
        if self.do_up:
            do_up(self)
        if self.do_right:
            do_right(self)
        if self.do_down:
            do_down(self)
        if self.do_left:
            do_left(self)
        if any(map(lambda x: pygame.sprite.collide_mask(self, x), barriers)) or not 0 <= self.rect.x < WINDOW_SIZE[0] \
                or not 0 <= self.rect.y < WINDOW_SIZE[1]:
            if self.do_up:
                do_down(self)
            if self.do_right:
                do_left(self)
            if self.do_down:
                do_up(self)
            if self.do_left:
                do_right(self)


def make_barrier(*group, x, y):
    barrier = pygame.sprite.Sprite(*group)
    barrier.image = load_image('box.png')
    barrier.rect = barrier.image.get_rect()
    barrier.rect.x, barrier.rect.y = x, y


def make_grass(*group, x, y):
    grass = pygame.sprite.Sprite(*group)
    grass.image = load_image('grass.png')
    grass.rect = grass.image.get_rect()
    grass.rect.x, grass.rect.y = x, y


def load_another_level(name: str, bgcolor=HERBAL_COLOR) -> (pygame.surface.Surface, Hero):
    hero = None
    enemies_spawns = []
    size = width, height = WINDOW_SIZE
    gm_screen = pygame.display.set_mode(size)
    gm_screen.fill(bgcolor)
    try:
        with open(name, 'r') as map_file:
            for i in range(WINDOW_SIZE[1] // SELL_SIZE[1]):
                line = map_file.readline()
                for j, elem in enumerate(line):
                    if elem == '0':
                        make_grass(all_sprites, x=j * SELL_SIZE[0], y=i * SELL_SIZE[1])
                        enemies_spawns.append((j * SELL_SIZE[0], i * SELL_SIZE[1]))
                    elif elem == '1':
                        make_barrier(barriers, all_sprites, x=j * SELL_SIZE[0], y=i * SELL_SIZE[1])
                    elif elem == '2':
                        make_grass(all_sprites, x=j * SELL_SIZE[0], y=i * SELL_SIZE[1])
                        for sprite in hero_group:
                            sprite.kill()
                        hero = Hero(hero_group, all_sprites, x=j * SELL_SIZE[0], y=i * SELL_SIZE[1])
    except FileNotFoundError:
        print(f"Файл с картой '{name}' не найден")
        sys.exit()
    return gm_screen, hero
